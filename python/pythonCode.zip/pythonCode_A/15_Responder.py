import RPi.GPIO as GPIO
from time import sleep

# led colour
red = 26 
yellow = 19
blue = 13

#set button pin
#Player's button
key1 = 23
key2 = 24
key3 = 25
#Button for the author
reset = 18  
flag = True  #One sign quantity for restriction, only one light can be on

GPIO.setmode(GPIO.BCM) #use BCM numbers
#set the led Pin OUTPUT mode
GPIO.setup(red,GPIO.OUT)  
GPIO.setup(yellow,GPIO.OUT)  
GPIO.setup(blue,GPIO.OUT)
#set the button pin INPUT mode and PUD_UP
GPIO.setup(key1,GPIO.IN,GPIO.PUD_UP)  
GPIO.setup(key2,GPIO.IN,GPIO.PUD_UP)  
GPIO.setup(key3,GPIO.IN,GPIO.PUD_UP)  
GPIO.setup(reset,GPIO.IN,GPIO.PUD_UP)  

while True:  #loop
    if not GPIO.input(key1) and flag == True:  #Judge if player 1's button is pressed
        GPIO.output(red,GPIO.HIGH)
        flag = False
    if not GPIO.input(key2) and flag == True:  #Judge if player 2's button is pressed
        GPIO.output(yellow,GPIO.HIGH)
        flag = False
    if not GPIO.input(key3) and flag == True:  #Judge if player 3's button is pressed
        GPIO.output(blue,GPIO.HIGH)
        flag = False
    if not GPIO.input(reset):  #The writer's button is pressed
        GPIO.output(red,GPIO.LOW)
        GPIO.output(yellow,GPIO.LOW)
        GPIO.output(blue,GPIO.LOW)
        flag = True

GPIO.cleanup()  #release all GPIO