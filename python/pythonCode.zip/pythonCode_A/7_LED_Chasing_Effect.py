import RPi.GPIO as GPIO
from time import sleep

#LED pin
led1 = 18
led2 = 23
led3 = 24
led4 = 25
led5 = 12
led6 = 16
led7 = 20
led8 = 21


GPIO.setmode(GPIO.BCM) # use BCM numbers
#set the ledPin OUTPUT mode
GPIO.setup(led1,GPIO.OUT)
GPIO.setup(led2,GPIO.OUT)
GPIO.setup(led3,GPIO.OUT)
GPIO.setup(led4,GPIO.OUT)
GPIO.setup(led5,GPIO.OUT)
GPIO.setup(led6,GPIO.OUT)
GPIO.setup(led7,GPIO.OUT)
GPIO.setup(led8,GPIO.OUT)

while True:
    #Led lights are lit one by one
    GPIO.output(led1,GPIO.HIGH)
    sleep(0.2)   # the delay size to control the speed of the water lamp 
    GPIO.output(led2,GPIO.HIGH)
    sleep(0.2)
    GPIO.output(led3,GPIO.HIGH)
    sleep(0.2)
    GPIO.output(led4,GPIO.HIGH)
    sleep(0.2)
    GPIO.output(led5,GPIO.HIGH)
    sleep(0.2)
    GPIO.output(led6,GPIO.HIGH)
    sleep(0.2)
    GPIO.output(led7,GPIO.HIGH)
    sleep(0.2)
    GPIO.output(led8,GPIO.HIGH)
    sleep(0.2)
    
    #Led lights go out one by one
    GPIO.output(led8,GPIO.LOW)
    sleep(0.2)
    GPIO.output(led7,GPIO.LOW)
    sleep(0.2)
    GPIO.output(led6,GPIO.LOW)
    sleep(0.2)
    GPIO.output(led5,GPIO.LOW)
    sleep(0.2)
    GPIO.output(led4,GPIO.LOW)
    sleep(0.2)
    GPIO.output(led3,GPIO.LOW)
    sleep(0.2)
    GPIO.output(led2,GPIO.LOW)
    sleep(0.2)
    GPIO.output(led1,GPIO.LOW)
    sleep(0.2)

GPIO.cleanup()  #release all GPIO