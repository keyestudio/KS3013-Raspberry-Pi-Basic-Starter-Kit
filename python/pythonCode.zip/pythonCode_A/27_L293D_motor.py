import RPi.GPIO as GPIO
import time

#define L293D pin
INA1 = 17
INA2 = 27
ENA = 22


GPIO.setmode(GPIO.BCM)

GPIO.setup(INA1,GPIO.OUT)
GPIO.setup(INA2,GPIO.OUT)
GPIO.setup(ENA,GPIO.OUT)

pwmA = GPIO.PWM(ENA,100)  #create a PWM instance
pwmA.start(0)   #start PWM

def forward():
    GPIO.output(INA1,GPIO.HIGH)
    GPIO.output(INA2,GPIO.LOW)
    pwmA.ChangeDutyCycle(100)
    
def back():
    GPIO.output(INA1,GPIO.LOW)
    GPIO.output(INA2,GPIO.HIGH)
    pwmA.ChangeDutyCycle(70)
    
def stop():
    pwmA.ChangeDutyCycle(0)
    
    
while True:     #loop
    forward()
    time.sleep(3)
    stop()
    time.sleep(2)
    back()
    time.sleep(3)
    stop()
    time.sleep(2)
    

pwmA.stop()  #stop PWM
GPIO.cleanup()    #release all GPIO
